
# Django Chat Application

A chat application built using django rest framework. The 
user can search other users and add them as a friend and have 
one to one chat with their friends.

## Screenshots

![image](/Images/search.jpg)

![image](/Images/chat.jpg)

## Installation of postgres
sudo sh -c 'echo "deb https://apt.postgresql.org/pub/repos/apt $(lsb_release -cs)-pgdg main" > /etc/apt/sources.list.d/pgdg.list'
wget --quiet -O - https://www.postgresql.org/media/keys/ACCC4CF8.asc | sudo apt-key add -
sudo apt-get update
sudo apt-get -y install postgresql
sudo systemctl start postgresql.service

## Installation of packages

pip install django
pip install django-rest-framework
pip install django-crispy_forms
pip install django-widget_tweaks
pip install django-crispy_bootstrap4
pip install crispy_bootstrap4
pip install psycopg2
$ pip install cryptography

## Setup the database
sudo su postgres
psql

create user kikati WITH PASSWORD 'kikati';
create database kikati;
grant all privileges on database kikati to kikati;


## How to use?

- Clone the repository
- Inside the project folder, open terminal

- Apply DB migrations by running the following commands in the terminal:
    python manage.py makemigrations
    python manage.py migrate

- Run the following command in the terminal to start the application:

    python manage.py runserver

- It will run the application on your localhost.
- Open the browser with the localhost address and enjoy the application.
