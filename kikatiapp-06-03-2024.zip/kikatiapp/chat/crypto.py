from cryptography.fernet import Fernet
import base64
from PyChat import settings

# print(Fernet.generate_key())
# ENCRYPTION_KEY = b'BHEdaEscaVdMdU1Ckr_LDnnXQATRSYgtIUu4gKE9MfI='

cipher_suite = Fernet(settings.ENCRYPTION_KEY)

def encrypt_text(text):
    # Encrypt the text and convert to Base64 string
    encrypted_text = cipher_suite.encrypt(text.encode())
    return base64.b64encode(encrypted_text).decode()

def decrypt_text(text):
    # Decode Base64 string and decrypt to get the text
    try:
        if text:
            encrypted_text = base64.b64decode(text.encode())
            return cipher_suite.decrypt(encrypted_text).decode()
    except:
        return None    
